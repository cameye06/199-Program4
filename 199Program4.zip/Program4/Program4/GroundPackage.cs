﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    class GroundPackage
    {
        private int _originZip;
        private int _destinationZip;
        private double _length;
        private double _width;
        private double _height;
        private double _lbs;

        public GroundPackage(int o=40202, int d=90210, double l=1.0, double w=1.0, double h=1.0, double lbs=1.0) // constructor
        {

            OriginZip = o;
            DestinationZip = d;
            Length = l;
            Width = w;
            Height = h;
            LBS = lbs;
        }
        public void SetGroundPackage(int o, int d, double l, double w, double h, double lbs) //setter
        {

            OriginZip = o;
            DestinationZip = d;
            Length = l;
            Width = w;
            Height = h;
            LBS = lbs;
        }

        public int OriginZip //origin zip Property
        {
            get // origin zip getter
            {
                return _originZip;
            }
            set //origin zip setter
            {
                if (value < 100000)
                { _originZip = value; }//sets _originZIP to imputed value
                else // When invalid
                { _originZip = 40202; } // sets _originZip to 40202
            }
        } // end of OriginZip

        public int DestinationZip //Destination Zip property
        {
            get  // destination zip Getter
            {
                return _destinationZip; //returnts _destinationZip
            }
            set  //destinationZip Setter
            {
                if (value < 100000) // has to be a 5 digit number
                { _destinationZip = value; } // sets _destinationZip to value
                else  // when not a 5 digit number
                { _destinationZip = 90210; } // sets _destinationZip to 90210 if fails 
            }// end of DestinationZip
        }
        public double Length //Length property
        {
            get  // Length Getter
            {
                return _length; //returnts_length
            }
            set  // Length Setter
            {
                if (value > 0) // has to be greater than 0
                { _length = value; } // sets _length to value
                else  // when less than one
                { _length = 1.0; } // sets _length to 1.0 if fails 
            }
           }// end of Length

        public double Width //width property
        {
            get  // width Getter
            {
                return _width; //returnts_width
            }
            set  //width Setter
            {
                if (value > 0) // has to be greater than 0
                { _width = value; } // sets _width to value
                else  // when less than one
                { _width = 1.0; } // sets_widthh to 1.0 if fails 
            }
        }// end of Width

        public double Height //Height property
        {
            get  // Height Getter
            {
                return _height; //returnts_height
            }
            set  //Height Setter
            {
                if (value > 0) // has to be greater than 0
                { _height = value; } // sets _height to value
                else  // when less than one
                { _height = 1.0; } // sets _weight to 1.0 if fails 
            }
        }// end of Height

        public double LBS//LBS property
        {
            get  // LBS Getter
            {
                return _lbs; //returnts _lbs
            }
            set  //LBS Setter
            {
                if (value > 0) // has to be greater than 0
                { _lbs = value; } // sets _lbs to value
                else  // when less than one
                { _lbs = 1.0; } // sets _lbs to 1.0 if fails 
            }
        }// end of Height

        public int ZoneDistance // zone distance method
        {
            get // zone distance property
            {
                return Math.Abs((_originZip/10000) - (_destinationZip / 10000)); // calcs the zone difference then returns it
            }
        }

        public double CalcCost()// calc cost method
        {
            const double NUMBER1 = .20; // numbers used for calculating cost
            const double NUMBER2 = .5;


            return NUMBER1 * (_length + _width + _height) + NUMBER2 * (ZoneDistance + 1) * _lbs ; // returns cost after math
        }

        public override string ToString() // ToString override
        {
            return  
                "Origin:" + _originZip.ToString()+Environment.NewLine
                +"Destination:" + _destinationZip.ToString() + Environment.NewLine
                + "Length:" + _length.ToString() + Environment.NewLine
                + "Width:" + _width.ToString() + Environment.NewLine
                + "Height:" + _height.ToString() + Environment.NewLine
                + "Weight:" + _lbs.ToString() + Environment.NewLine; // sets ToString to print the details of the package
        }
    }
}

