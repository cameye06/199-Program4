﻿namespace Program4
{
    partial class Prog4Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.originLable = new System.Windows.Forms.TextBox();
            this.destLable = new System.Windows.Forms.TextBox();
            this.widthLable = new System.Windows.Forms.TextBox();
            this.lengthLable = new System.Windows.Forms.TextBox();
            this.weightLable = new System.Windows.Forms.TextBox();
            this.heightLable = new System.Windows.Forms.TextBox();
            this.priceList = new System.Windows.Forms.ListBox();
            this.Details = new System.Windows.Forms.Button();
            this.toUofL = new System.Windows.Forms.Button();
            this.fromUofL = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // originLable
            // 
            this.originLable.Location = new System.Drawing.Point(91, 21);
            this.originLable.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.originLable.Name = "originLable";
            this.originLable.Size = new System.Drawing.Size(141, 20);
            this.originLable.TabIndex = 0;
            // 
            // destLable
            // 
            this.destLable.Location = new System.Drawing.Point(91, 52);
            this.destLable.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.destLable.Name = "destLable";
            this.destLable.Size = new System.Drawing.Size(141, 20);
            this.destLable.TabIndex = 1;
            // 
            // widthLable
            // 
            this.widthLable.Location = new System.Drawing.Point(91, 116);
            this.widthLable.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.widthLable.Name = "widthLable";
            this.widthLable.Size = new System.Drawing.Size(141, 20);
            this.widthLable.TabIndex = 3;
            // 
            // lengthLable
            // 
            this.lengthLable.Location = new System.Drawing.Point(91, 83);
            this.lengthLable.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lengthLable.Name = "lengthLable";
            this.lengthLable.Size = new System.Drawing.Size(141, 20);
            this.lengthLable.TabIndex = 2;
            // 
            // weightLable
            // 
            this.weightLable.Location = new System.Drawing.Point(91, 175);
            this.weightLable.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.weightLable.Name = "weightLable";
            this.weightLable.Size = new System.Drawing.Size(141, 20);
            this.weightLable.TabIndex = 5;
            // 
            // heightLable
            // 
            this.heightLable.Location = new System.Drawing.Point(91, 146);
            this.heightLable.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.heightLable.Name = "heightLable";
            this.heightLable.Size = new System.Drawing.Size(141, 20);
            this.heightLable.TabIndex = 4;
            // 
            // priceList
            // 
            this.priceList.FormattingEnabled = true;
            this.priceList.Location = new System.Drawing.Point(235, 21);
            this.priceList.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.priceList.Name = "priceList";
            this.priceList.Size = new System.Drawing.Size(223, 212);
            this.priceList.TabIndex = 6;
            // 
            // Details
            // 
            this.Details.Location = new System.Drawing.Point(471, 42);
            this.Details.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Details.Name = "Details";
            this.Details.Size = new System.Drawing.Size(67, 38);
            this.Details.TabIndex = 7;
            this.Details.Text = "Details";
            this.Details.UseVisualStyleBackColor = true;
            this.Details.Click += new System.EventHandler(this.Details_Click);
            // 
            // toUofL
            // 
            this.toUofL.Location = new System.Drawing.Point(471, 103);
            this.toUofL.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.toUofL.Name = "toUofL";
            this.toUofL.Size = new System.Drawing.Size(67, 38);
            this.toUofL.TabIndex = 8;
            this.toUofL.Text = "Send to UofL";
            this.toUofL.UseVisualStyleBackColor = true;
            this.toUofL.Click += new System.EventHandler(this.toUofL_Click);
            // 
            // fromUofL
            // 
            this.fromUofL.Location = new System.Drawing.Point(471, 165);
            this.fromUofL.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.fromUofL.Name = "fromUofL";
            this.fromUofL.Size = new System.Drawing.Size(67, 38);
            this.fromUofL.TabIndex = 9;
            this.fromUofL.Text = "Send from UofL";
            this.fromUofL.UseVisualStyleBackColor = true;
            this.fromUofL.Click += new System.EventHandler(this.fromUofL_Click);
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(8, 207);
            this.Add.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(223, 27);
            this.Add.TabIndex = 10;
            this.Add.Text = "Add Ground Package";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(23, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 11;
            this.label1.Text = "Origin Zip:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(21, 53);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 12;
            this.label2.Text = "Dest. Zip:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(21, 84);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 13;
            this.label3.Text = "Length:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(21, 117);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 15);
            this.label4.TabIndex = 14;
            this.label4.Text = "Width:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(21, 147);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 15);
            this.label5.TabIndex = 15;
            this.label5.Text = "Height:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(23, 177);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 15);
            this.label6.TabIndex = 16;
            this.label6.Text = "Weight:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Prog4Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(562, 264);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.fromUofL);
            this.Controls.Add(this.toUofL);
            this.Controls.Add(this.Details);
            this.Controls.Add(this.priceList);
            this.Controls.Add(this.weightLable);
            this.Controls.Add(this.heightLable);
            this.Controls.Add(this.widthLable);
            this.Controls.Add(this.lengthLable);
            this.Controls.Add(this.destLable);
            this.Controls.Add(this.originLable);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Prog4Form";
            this.Text = "Program 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox originLable;
        private System.Windows.Forms.TextBox destLable;
        private System.Windows.Forms.TextBox widthLable;
        private System.Windows.Forms.TextBox lengthLable;
        private System.Windows.Forms.TextBox weightLable;
        private System.Windows.Forms.TextBox heightLable;
        private System.Windows.Forms.ListBox priceList;
        private System.Windows.Forms.Button Details;
        private System.Windows.Forms.Button toUofL;
        private System.Windows.Forms.Button fromUofL;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

