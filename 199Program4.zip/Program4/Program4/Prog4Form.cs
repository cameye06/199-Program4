﻿/* 
 * B8426
 * CIS 199
 * Section 02
 * Program 4
 * due: 4/25/2017
 * 
 * this program takes in details of a shipment
 * it creates objects for each shipment
 * then finds the cost and prints it to a listbox
 * it allow you to select the lsit box inxed and see details, or change destination or origin to 40292
 * 
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program4
{
    public partial class Prog4Form : Form
    {
       // GroundPackage NewPackage = new GroundPackage();
        public Prog4Form()
        {
            InitializeComponent();
        }
        
        const int SIZE = 100; //CONSTANT used to make there be 100 possible packages
        GroundPackage[] NewPackage = new GroundPackage[SIZE]; // creates 100 package
        int i = 0; // int named i (for "index") used in Add.Click to populate one GroundPackage object per click

        public void Add_Click(object sender, EventArgs e)
        {

            
            NewPackage[i] = new GroundPackage(); // creates a new GroundPackage for every time button is clicked

            if (string.IsNullOrWhiteSpace(originLable.Text) == false ||    //test to see if ant of the fields are blank
                string.IsNullOrWhiteSpace(destLable.Text) == false ||
                string.IsNullOrWhiteSpace(lengthLable.Text) == false ||
                string.IsNullOrWhiteSpace(widthLable.Text) == false ||
                string.IsNullOrWhiteSpace(heightLable.Text) == false ||
                string.IsNullOrWhiteSpace(weightLable.Text) == false)
            {
                NewPackage[i].OriginZip = int.Parse(originLable.Text); // sets NewPackage[i]'s OriginZip to originLable
                NewPackage[i].DestinationZip = int.Parse(destLable.Text); // sets NewPackage[i]'s DestinationZip to destLable
                NewPackage[i].Length = double.Parse(lengthLable.Text); // sets NewPackage[i]' Length to lengthLable
                NewPackage[i].Width = double.Parse(widthLable.Text); // sets NewPackage's Width to widthLable
                NewPackage[i].Height = double.Parse(heightLable.Text); // sets NewPackage's Height to heightLable
                NewPackage[i].LBS = double.Parse(weightLable.Text); // sets   NewPackage's weight (LBS) to weightLable

                priceList.Items.Add(NewPackage[i].CalcCost().ToString("C")); // prints NewPackage[i].CalcCost() to next empty index in priceList

                originLable.Text = String.Empty;//these clear the textboxes used to enter info on package
                destLable.Text = String.Empty;//^
                lengthLable.Text = String.Empty;//^
                widthLable.Text = String.Empty;//^
                heightLable.Text = String.Empty;//^
                weightLable.Text = String.Empty;//^

                priceList.SelectedIndex = 0;//sets the Price list to select the first index, so I do not have to account for one not being selected

                i++; // adds one to i so that every time button is clicked it makes a new object
            }
            else { MessageBox.Show("You must enter all of the details of the package"); } // returns a text box if any of the fields are empty
        }

        private void Details_Click(object sender, EventArgs e) // when clicked it shows details of GroundPackage selected
        {
            int x = priceList.SelectedIndex; // sets x to the index selected in priceList
            MessageBox.Show(NewPackage[x].ToString()); // uses GroundPackage's ToStreing override to print details at selected index
            

        }

        public void toUofL_Click(object sender, EventArgs e) // sets the destination of the package to 40292
        {
            int x = priceList.SelectedIndex; // sets x to nselected index number
            NewPackage[x].DestinationZip = 40292; // sets selected package's destination to 40292
            priceList.Items.RemoveAt(x); // removes old calculation from pricelist
            priceList.Items.Insert(x, NewPackage[x].CalcCost().ToString("C")); // inserts new calculation to priceList in same spot as removed
            priceList.SelectedIndex = x; //sets the Price list to select the last selected index, so I do not have to account for one not being selected
            MessageBox.Show("Destination Updated"); // message box confirms update
        }

        private void fromUofL_Click(object sender, EventArgs e) // sets the origin of the package to 40292
        {
            int x = priceList.SelectedIndex; // sets x to nselected index number
            NewPackage[x].OriginZip = 40292;// sets selected package's origin to 40292
            priceList.Items.RemoveAt(x); // removes old calculation from pricelist
            priceList.Items.Insert(x, NewPackage[x].CalcCost().ToString("C")); // inserts new calculation to priceList in same spot as removed
            priceList.SelectedIndex = x; //sets the Price list to select the last selected index, so I do not have to account for one not being selected
            MessageBox.Show("Origin Updated"); // message box confirms update
        }
    }
}
